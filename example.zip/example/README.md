# Example Graph Bundle

This is an example of a graph bundle.  The archive contains 8 graphs in DOT
format which describe function call graphs of Android applications.

## Bundle Format 

_File suffix:_ Every file entry in the archive with a `dot` suffix is
considered a graph in DOT format.  All other files are ignored.

_File label:_ Siggie can extract a file label from the name of a file entry
using a regular expression.  By default, this regular expression matches
numbers at the beginning of file names.  For example, the file entry
`042_graph.dot` has the label `42`. Note that leading zeros are dropped.

_Node labels:_ The nodes of each graph should be labeled using the 
attribute `label`.

